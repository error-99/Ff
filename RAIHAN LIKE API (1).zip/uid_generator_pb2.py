# youtube Raihan.08 gamer
# Telegram raihanpaid
#DONT CHANGE CREDIT 
#IF YOU CHANGE MY CREDIT, I'LL FUCK YOUR MOM

# Protobuf Python Version: 4.25.1
"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
# @@protoc_insertion_point(imports)

_sym_db = _symbol_database.Default()

#FUCKED BY JOBAYAR AHMED @JOBAYAR_AHMED
#DONT CHANGE CREDIT 
#IF YOU CHANGE MY CREDIT, I'LL FUCK YOUR MOM

DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x13uid_generator.proto\"5\n\ruid_generator\x12\x10\n\x08krishna_\x18\x01 \x01(\x03\x12\x12\n\nteamXdarks\x18\x02 \x01(\x03\x62\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'uid_generator_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
  DESCRIPTOR._options = None
  _globals['_UID_GENERATOR']._serialized_start=23
  _globals['_UID_GENERATOR']._serialized_end=76
# Youtube Raihan.08 gamer
#Telegram raihanpaid
#DONT CHANGE CREDIT 
#IF YOU CHANGE MY CREDIT, I'LL FUCK YOUR MOM